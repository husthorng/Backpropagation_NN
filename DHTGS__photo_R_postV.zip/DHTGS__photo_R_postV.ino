

#include <ESP8266WiFi.h>
#include "HTTPSRedirect.h"
#include <WiFiClientSecure.h>
#include <Wire.h>

#include "DHT.h"


#define BLYNK_TEMPLATE_ID "TMPLw4s4yveQ"
#define BLYNK_TEMPLATE_NAME "Quickstart Template"
#define BLYNK_AUTH_TOKEN "x17w9tXXcTg6pVaPJh9VxEXEmf0n8Dxs"
//https://blynk.cloud/dashboard/180590/global/devices/1/organization/180590/devices/3765795/dashboard
//hustvsc1@  ma2496

#define BLYNK_PRINT Serial
#include <BlynkSimpleEsp8266.h>
char auth[] = BLYNK_AUTH_TOKEN;


#define DHTTYPE DHT11   // DHT 11

#define DHTPIN 14 //connect DHT data pin to D5
#define BUTTON_PIN 12   //D6
#define buzzer 13       //D7
#define Led 15       //D8
#define relay_PIN 16    //D0
              
DHT dht(DHTPIN, DHTTYPE);
// Fill ssid and password with your network credentials


char ssid[] = "CHT7947";
char pass[] = "0492553968";

//char ssid[] = "husthung";
//char pass[] = "ma2553968";


int outputpin = A0;
int analogValue ;
float millivolts ;


String payload = "";
String payload1 = "";
String payload2 = "";

HTTPSRedirect* client = nullptr;

float temp; //to store the temperature value
float hum; // to store the humidity value
float ctemp = 30;
float chumi= 80;
      
const char* host = "script.google.com";

String payload_base =  "{\"command\": \"insert_row\", \"sheet_name\": \"DHT\", \"values\": ";
const int httpsPort = 443;

void sendData(float value0, float value1, float value2) {
      String GAS_ID = "AKfycbx3xnS8DhOPZid4HCH93XGqVGTtZ10_-brdIrWMXYBlYbnvvSthlPkEz5x40Afu_dzbdg"; //my_dht hung
      //https://docs.google.com/spreadsheets/d/1MlxZCT7ShgrzuBD0uDADjmMLfpssArgr5-kyvw2uqFQ/edit?gid=0#gid=0

      //String GAS_ID = "AKfycbzcGx-nZqvd1H47cLMkSki8SWLlN9IC5sKLR8ueHr-TzbOOWUfbO_PpeheRna122CAn"; //my_dht.xcel DHT3
      //https://docs.google.com/spreadsheets/d/10VT8lpb7MIKEOMmKfqIKSh-yoNaYBsMx3mFdp8shjxU/edit?gid=0#gid=0

      String url = String("/macros/s/") + GAS_ID+ "/exec";

        payload = payload_base + "\"" + value0 + "," + value1 + "," + value2 + "\"}";

        Serial.println(value2);
      // Publish data to Google Sheets
        Serial.println("Publishing data...");
        Serial.println(payload);
        if(client->POST(url, host, payload)){ 
          // do stuff here if publish was successful
        }
        else{
          // do stuff here if publish was not successful
          Serial.println("Error while connecting");
        }

        // a delay of several seconds is required before publishing again    
        delay(1000);
        //----------------------------------------Processing data and sending data
        
} 
BLYNK_WRITE(V0) // At global scope (not inside of the function)
{
    int i=param.asInt();
    if (i==1) 
    {
        digitalWrite(relay_PIN, HIGH);
        Blynk.virtualWrite(V11,HIGH);        
        digitalWrite(Led, HIGH);
//        digitalWrite(buzzer,HIGH);
       tone(buzzer,1319);

  
    }
    else 
    {
        digitalWrite(relay_PIN, LOW);
        Blynk.virtualWrite(V11,LOW);           
        digitalWrite(Led, LOW);  
        digitalWrite(buzzer,LOW);
    }
}




void setup() {
  
  Serial.begin(115200);
  Serial.println();
  Serial.print("Connecting to wifi: ");
  Serial.println(ssid);
  pinMode(Led, OUTPUT);
  digitalWrite(Led, LOW);
  pinMode(outputpin, INPUT);
  pinMode(BUTTON_PIN, INPUT);
  
  pinMode(DHTPIN, OUTPUT);
  pinMode(buzzer, OUTPUT);
  
  pinMode( relay_PIN,OUTPUT);
  digitalWrite(buzzer, LOW);  
//  delay(2000);
  dht.begin();          //Begins to receive Temperature and humidity values.  
 Blynk.begin(auth, ssid, pass);
 // Blynk.begin(auth, ssid, password);  
  WiFi.begin(ssid, pass);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("");
  Serial.println("WiFi connected");
  Serial.println("IP address: ");
  Serial.println(WiFi.localIP());
}

void loop() {
      temp = dht.readTemperature();
      hum = dht.readHumidity();
      analogValue = analogRead(outputpin);
      millivolts = (analogValue/1024.0) * 100;

      Serial.print("temperature = ");
      Serial.println(temp);
      Serial.print("humidity = ");
      Serial.println(hum);
      Serial.print("millivolts = ");
      Serial.println(millivolts);

      Blynk.virtualWrite(V2,millivolts);

      static int error_count = 0;
      static int connect_count = 0;
      const unsigned int MAX_CONNECT = 20;
      static bool flag = false;
        if (!flag){
          client = new HTTPSRedirect(httpsPort);
          client->setInsecure();
          flag = true;
          client->setPrintResponseBody(false);
          client->setContentTypeHeader("application/json");
        }

        if (client != nullptr){
          if (!client->connected()){
            client->connect(host, httpsPort);
          }
        }
        else{
          Serial.println("Error creating client object!");
          error_count = 5;
        }
        
        if (connect_count > MAX_CONNECT){
        
          connect_count = 0;
          flag = false;
          delete client;
          return;
        }
        // Add some delay in between checks
        delay(1000);
//        int ctemp = payload1.toInt();
//        int chumi= payload2.toInt();
      
       
      if(millivolts <= 50) //photoresitor millivolts
      {
//        digitalWrite(relay_PIN,HIGH);  //rely on
        digitalWrite(Led,HIGH);  
        digitalWrite(buzzer,HIGH);  
        Blynk.virtualWrite(V11,HIGH);  
      }
      else {
//        digitalWrite(relay_PIN,LOW);  
        digitalWrite(Led,LOW);
        digitalWrite(buzzer,LOW);  
        Blynk.virtualWrite(V11,LOW);    
      }
      sendData(temp, hum, millivolts); //--> Calls the sendData Subroutine



}




